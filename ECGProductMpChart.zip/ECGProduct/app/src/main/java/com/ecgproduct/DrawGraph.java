package com.ecgproduct;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.util.Log;
import android.widget.LinearLayout;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

import static java.lang.Thread.sleep;

/**
 * Created by aaa on 6/20/2017.
 */

public class DrawGraph {
    private final static int REFRESH_INTERVAL = 1; // 1 refresh interval
    private final static int QueueSize = 1000;
    private int[] mHrmQueue = new int[QueueSize];
    private int mHrmQueueCounter = 0;
    private LineChart mChart;
    public BlockingDeque<Integer> dequeEcgFromDevice = new LinkedBlockingDeque<>();
    public BlockingDeque<Integer> dequeEcgForGraph = new LinkedBlockingDeque<>();
    public boolean isfirst = true;


    private final static int X_LENGTH = 500;
    private float MAX = 3000;
    private float MIN = 0;

    //    ---------------BEGIN Calculate Average Ecg Count ---------------------------------
    int hrMAX = 10;
    int[] hrQueue = new int[hrMAX];
    int hrIndex = 0;

    int drawCount = 0;
    long drawTime = -1;
    int firstHRSize = 0;
    int nXBufferSize = 0;
    LinearLayout lyt_chart;
    Context mContext;
    DrawGraph(LinearLayout lyt_chartfrom, Context context){
        dequeEcgForGraph = new LinkedBlockingDeque<>();
        dequeEcgFromDevice = new LinkedBlockingDeque<>();
//        Thread bufferthread;
//        bufferthread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                for (;;) {
//                    try {
//                        buffering();
//                        sleep(2);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });
//        bufferthread.start();

        lyt_chart = lyt_chartfrom;
        mContext = context;
        mChart = new LineChart(context);
        initChart();
        timerHandler = new Handler();
        timerHandler.postDelayed(runnableFroDraw, 10);
//        demoHandler = new Handler();
//        demoHandler.postDelayed(demo,100);

    }
    public void buffering() throws InterruptedException {

        int nEcgDevSize = dequeEcgFromDevice.size();
        Log.i("buffering","buffering" + nEcgDevSize);
        if(nEcgDevSize> 0){
            dequeEcgForGraph.addLast(dequeEcgFromDevice.takeFirst());
            if(dequeEcgForGraph.size() > 500){
                isfirst = false;
            }
            Log.i("deque_size", dequeEcgForGraph.size()+"");
        }
    }
    public void initChart(){
        if(((LinearLayout) lyt_chart).getChildCount() > 0)
            ((LinearLayout) lyt_chart).removeAllViews();
        mChart.setTouchEnabled(true);
        // enable scaling and dragging
        mChart.setDragEnabled(true);
        mChart.setScaleXEnabled(true);
        mChart.setScaleYEnabled(true);

        mChart.setDrawGridBackground(false);
        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(false);
        // set an alternative background color
        mChart.setBackgroundColor(Color.TRANSPARENT);
        //Begin multi line
        LineData data = new LineData();
        data.setValueTextColor(Color.GRAY);
        // add empty data
        mChart.setData(data);
        // get the legend (only possible after setting data)
        Legend legend = mChart.getLegend();
        // modify the legend ...
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextColor(Color.GRAY);
        legend.setEnabled(false);
        XAxis xl = mChart.getXAxis();
        xl.setTextColor(Color.GRAY);
        xl.setDrawGridLines(true);
        xl.setDrawLabels(true);
        YAxis leftAxis;
        leftAxis = mChart.getAxisLeft();
        leftAxis.setTextColor(Color.GRAY);
        leftAxis.setAxisMaximum(3000);
        leftAxis.setAxisMinimum(0);
        leftAxis.setDrawGridLines(true);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(false);
        Description des = mChart.getDescription();
        des.setEnabled(false);
        lyt_chart.post(new Runnable(){
            public void run(){
                Log.i("Width", " "+ lyt_chart.getWidth());
                mChart.setMinimumWidth(lyt_chart.getMeasuredWidth());
                mChart.setMinimumHeight(lyt_chart.getMeasuredHeight());
            }
        });
        lyt_chart.addView(mChart);
    }
    public void clearVal(){
        nXBufferSize = 0;
        mChart = new LineChart(mContext);
        dequeEcgFromDevice.clear();
        dequeEcgForGraph.clear();
        isfirst = true;
        initChart();
    }
    public int averageHRCount() {
        if (firstHRSize == 0) return 1;
        int total = 0;
        for (int i = 0; i < firstHRSize; i++) {
            total += hrQueue[i];
        }
        total = total / firstHRSize;
        return total;
    }

    //    ---------------END Calculate Average Ecg Count ---------------------------------

    //    ----------------BEGIN Calculate Average Fetch ( Drawing ) Count --------------------------------
    int drMAX = 10;
    int[] drQueue = new int[drMAX];
    int drIndex = 0;
    int firstDRSize = 0;
    public int averageDrawingCount() {
        if (firstDRSize == 0) return 1;
        int total = 0;
        for (int i = 0; i < firstDRSize; i++) {
            total += drQueue[i];
        }
        total = total / firstDRSize;
        return total;
    }
    //    ----------------END Calculate Average Fetch ( Drawing ) Count --------------------------------

    int fetchCount = 0;
    Handler timerHandler;
    Handler demoHandler;
    int demonum = 1;
    Runnable demo = new Runnable() {
        @Override
        public void run() {
            if(demonum < 3000)
                demonum++;
            if(demonum >= 3000)
                demonum = 0;
            enQueue(demonum);
            Log.i("Draw","Draw" + demonum);
            demoHandler.postDelayed(demo,1);
        }
    };

    final Runnable runnableFroDraw = new Runnable() {
        @Override
        public void run() {
            addEntry();
            timerHandler.postDelayed(this, 5);
        }
    };
    private boolean isFullQueue() {
        return mHrmQueueCounter == QueueSize;
    }

    private boolean isEmptyQueue() {
        return mHrmQueueCounter < 5;
    }
    // END management Queue

    private void addEntry() {
        if(isfirst)
            return;
        if(dequeEcgFromDevice.size()<0)
            return;
//        if (isEmptyQueue()) return;

        LineData data = mChart.getData();

        if (data != null) {

            ILineDataSet set = data.getDataSetByIndex(0);

            if (set == null) {
                set = createSet();
                data.addDataSet(set);
            }

            for (int i = 0; i < 12; i++) {
                Log.i("deque",""+dequeEcgFromDevice.size());
                if (dequeEcgFromDevice.size()<1) break;
                try {
                    data.addEntry(new Entry(nXBufferSize, dequeEcgFromDevice.takeFirst()), 0);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                nXBufferSize++;
            }

//            // n page show
//            if (set.getEntryCount() > X_LENGTH*5 ) {
//                for (int j = 0; j < 100; j++) {
//                    set.removeFirst();
//                }
//            }

            MIN = data.getYMin();
            MAX = data.getYMax();
            data.notifyDataChanged();
            mChart.notifyDataSetChanged();
            mChart.setVisibleXRangeMaximum(X_LENGTH);
            mChart.moveViewTo(nXBufferSize, (MIN + MAX) / 2, mChart.getAxisLeft().getAxisDependency());
        }
    }

    public void enQueue(int value) {
        dequeEcgFromDevice.addLast((Integer) value);
        Log.i("enque", value+":"+dequeEcgFromDevice.size());
        if(dequeEcgFromDevice.size()>500)
            isfirst = false;
    }

    private int deQueue() {
        if(dequeEcgFromDevice.size() > 0) {
            try {
                Log.i("deque", dequeEcgFromDevice.size()+"");
                return dequeEcgFromDevice.takeFirst();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return 1500;
    }

    private LineDataSet createSet() {
        LineDataSet set = new LineDataSet(null, "ECG");
        set.setColor(Color.rgb(238,238,238));
        set.setMode(LineDataSet.Mode.LINEAR);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setColor(ColorTemplate.getHoloBlue());
        set.setCircleColor(ColorTemplate.getHoloBlue());
        set.setLineWidth(2f);
        set.setCircleRadius(1f);
        set.setFillAlpha(65);
        set.setFillColor(ColorTemplate.getHoloBlue());
        set.setHighLightColor(Color.rgb(238,238,238));
        set.setValueTextColor(Color.RED);
        set.setValueTextSize(9f);
        set.setDrawValues(true);
        return set;
    }
}
